#include "cmsis_os2.h"                          // CMSIS RTOS header file
#include "stm32f4xx_hal.h"

int Init_ThLed1 (void);
int Init_ThLed2 (void);
int Init_ThLed3 (void);
