#ifndef __TEST_APP_H__
#define __TEST_APP_H__
#include <stdio.h>
#include <stdint.h>
#include "../../stm_err.h"

stm_err_t init_test_app(void);

#endif
