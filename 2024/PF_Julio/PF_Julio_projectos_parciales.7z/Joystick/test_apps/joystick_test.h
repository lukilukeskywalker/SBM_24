#ifndef __JOYSTICK_TEST__
#define __JOYSTICK_TEST__
//#define JOY_PULSE_VERBOSE 1
#include "../joystick.h"

#include "cmsis_os2.h"                  // ::CMSIS:RTOS2

stm_err_t init_test_app(void);
#endif

