#ifndef __TEST_APP__
#define __TEST_APP__
#include "../../stm_err.h"

stm_err_t init_test_app(void);

#endif