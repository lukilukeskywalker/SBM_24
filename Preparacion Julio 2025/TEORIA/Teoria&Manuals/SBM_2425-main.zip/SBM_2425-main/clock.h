#ifndef __CLOCK_H
#define __CLOCK_H

/*----------------------------------------------------------------------------
 *      Thread 'clock': ADC 27/NOV/24
 *---------------------------------------------------------------------------*/

int Init_clock_Thread (void);
uint8_t horas, minutos, segundos;

#endif
