#include "cmsis_os2.h"                          // CMSIS RTOS header file
#include "clock.h"

/*----------------------------------------------------------------------------
 *      Thread 'clock': ADC 27/NOV/24
 *---------------------------------------------------------------------------*/

#define TEST 0

#ifdef TEST
void joy_test(void);
void Leds_init(void);
#endif

/*---------CLOCK SOURCE TIMER--------*/
static osTimerId_t id_clock_tmr;
static void clock_Callback(void);

/*****************************************************************************/

osThreadId_t tid_clock_Thread;                        // thread id
void clock_Thread (void *argument);                   // thread function

int Init_clock_Thread (void) {

  tid_clock_Thread = osThreadNew(clock_Thread, NULL, NULL);
  if (tid_clock_Thread == NULL) {
    return(-1);
  }

  return(0);
}

void clock_Thread (void *argument) {

  id_clock_tmr = osTimerNew(clock_Callback, osTimerPeriodic, NULL, NULL);

  horas = minutos = segundos = 0; // Inicialización a cero

#ifdef TEST
  horas     = 23;
  minutos   = 59;
  segundos  = 55;
#endif

  while (1) {
    /**************NOTHING TO SEE HERE, OSTIMER INTERRUPT CONTROLLED**************/
    osThreadYield();
  }
}


/*****************************************************************************/
static void clock_Callback(void)
{
  segundos++;
  #ifdef TEST
    HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_0);
  #endif

  /*if clk'event and clk = 1*/
  if (segundos == 60)
  {
    segundos = 0;
    minutos++;
#ifdef TEST
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_SET);
#endif
  }

  if (minutos == 60)
  {
    minutos = 0;
    horas++;
#ifdef TEST
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_SET);
#endif
  }

  if(horas == 24)
  {
    horas = 0;
  }

}

/*****************************************************************************/
#ifdef TEST
/**TEST**/
static void clock_test(void)
{


}

void Leds_init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct;

  __HAL_RCC_GPIOB_CLK_ENABLE();

  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_HIGH;

  //LD0, LD1, LD2
  GPIO_InitStruct.Pin = GPIO_PIN_0 | GPIO_PIN_7 | GPIO_PIN_14;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}
#endif
